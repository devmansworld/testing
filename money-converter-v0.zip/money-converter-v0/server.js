const express = require("express");
const fs = require("fs");
const app = express();
const port = 3000;

let currencyData = JSON.parse(fs.readFileSync("rates.json", "utf-8"));

app.use(express.static("public")); // serve frontend

// Convert money: /convert?from=USD&to=CLP&amount=10
app.get("/convert", (req, res) => {
  const { from, to, amount } = req.query;

  if (!from || !to || !amount) {
    return res.status(400).json({ error: "Missing parameters (from, to, amount)" });
  }

  const fromRate = currencyData.rates[from.toUpperCase()];
  const toRate = currencyData.rates[to.toUpperCase()];

  if (!fromRate || !toRate) {
    return res.status(400).json({ error: "Unsupported currency" });
  }

  const usdValue = amount / fromRate;
  const converted = usdValue * toRate;

  res.json({
    from,
    to,
    amount: Number(amount),
    result: converted,
    lastUpdated: currencyData.lastUpdated
  });
});

app.listen(port, () => {
  console.log(`V0 Money converter running at http://localhost:${port}`);
});
